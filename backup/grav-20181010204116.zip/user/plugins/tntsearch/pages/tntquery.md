---
title: TNTSearch Query
template_format: json
---