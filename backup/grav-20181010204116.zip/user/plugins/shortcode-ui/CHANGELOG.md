# v2.2.5
## 05/16/2017

1. [](#bugfix)
    * Resoled issue with fixed height of accordion [#20](https://github.com/getgrav/grav-plugin-shortcode-ui/issues/20)

# v2.2.4
## 04/25/2017

1. [](#improved)
    * Added the ability to set `class=""` on the `ui-callout` shortcode [#19](https://github.com/getgrav/grav-plugin-shortcode-ui/pull/19)
    * Allow the ability to set an `id="""` on tabs [#16](https://github.com/getgrav/grav-plugin-shortcode-ui/pull/16)

# v2.2.3
## 03/04/2017

1. [](#bugfix)
    * Fixed a `z-index` issue in `AccordionShortcode`
    
# v2.2.2
## 03/04/2017

1. [](#bugfix)
    * Renamed `AccordionShortcode` to avoid conflict with `GravStrap` plugin.

# v2.2.1
## 03/03/2017

1. [](#bugfix)
    * Typo! Renamed `accordian` to `accordion`

# v2.2.0
## 03/02/2017

1. [](#new)
    * Added new `accordian` shortcode

# v2.1.0
## 02/25/2017

1. [](#new)
    * Added new `polaroid` shortcode
1. [](#bugfix)
    * Add support for autoescaping in Twig

# v2.0.0
## 02/11/2016

1. [](#improved)
    * Refactored to work with `shortcode-core` v2.0.0

# v1.0.1
## 01/18/2016

1. [](#improved)
    * Added a 'shortcode-core' dependency

# v1.0.0
## 01/18/2016

1. [](#new)
    * ChangeLog started...
